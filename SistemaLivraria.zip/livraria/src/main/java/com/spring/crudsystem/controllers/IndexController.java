package com.spring.crudsystem.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class IndexController {
/*
	@RequestMapping("/")
	public String index() {
		return "index";
	}
*/
}
