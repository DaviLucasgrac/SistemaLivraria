package com.spring.crudsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
